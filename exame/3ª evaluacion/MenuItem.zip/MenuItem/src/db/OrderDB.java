/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.util.HashMap;
import model.MenuItem;
import model.Order;
import model.OrderItem;

/**
 *
 * @author ivan.fernandezguinde
 */
public class OrderDB {
    private HashMap<Order.getMesa, Order> pedido = new HashMap();

    
    public static MenuItem findById(int id) {
        for (int=0; i<OrderItem.)
        
    }
    
    
    
}
