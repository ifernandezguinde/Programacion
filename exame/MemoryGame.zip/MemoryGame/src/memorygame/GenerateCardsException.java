/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

/**
 *
 * @author ivan.fernandezguinde
 */
public class GenerateCardsException extends Exception {
    /**
     * Construtor que recibe unha mensaxe de erro
     * @param message 
     */
    public GenerateCardsException(String message) {
        super(message);
    }
}
