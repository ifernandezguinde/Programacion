/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import Model.Booking;
import java.util.ArrayList;
import java.util.Date;

/**
 * inclúe os métodos para gardar e acceder ás reservas da aplicación
 * @author ivan.fernandezguinde
 */
public class BookingDB {
    public static ArrayList findByDate(Date date) {
        
    }
    
    public static ArrayList findByUserAndDate(String id, Date date) {
        
    }
    
    public static void save(Booking booking) {
        
    }
    
    
    
}
