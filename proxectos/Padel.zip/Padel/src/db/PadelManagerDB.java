/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * mantén as estruturas dinámicas que almacenan todos os obxectos da aplicación
 * @author ivan.fernandezguinde
 */
public class PadelManagerDB {
    private final static Player PLAYERS = new HashMap();
    private final static PadelCourt  COURTS = new ArrayList();
    private final static Booking BOOKINGS = new ArrayList();
    
}
