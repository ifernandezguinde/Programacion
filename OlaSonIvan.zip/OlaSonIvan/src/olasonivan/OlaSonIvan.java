/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package olasonivan;

/**
 *Este programa escribe o texto "Ola, son Ivan" na consola usando o metodo System.out.println() e foi creado por Ivan Fernandez Guinde
 * @author ivan.fernandezguinde
 */
public class OlaSonIvan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //mostra unha imaxen por pantalla
        System.out.println("Ola, son Ivan");
    }
    
}
